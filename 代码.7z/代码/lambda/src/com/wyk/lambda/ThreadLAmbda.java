package com.wyk.lambda;

import java.util.function.Function;
import java.util.function.IntBinaryOperator;

public class ThreadLAmbda {

    public static void main(String[] args) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("你知道吗！");
                System.out.println("你知道吗！");
                System.out.println("你知道吗呜呼呼");
                System.out.println("你知道吗666！");
                 System.out.println("你知道吗5555！");
            }
        }).start();



    /*    //匿名内部类
        int n = calculateNum(new IntBinaryOperator() {
            @Override
            public int applyAsInt(int left, int right) {
                return left + right;
            }
        });
        System.out.println(n);

        //lambda表达式
        int i = calculateNum((int left, int right)-> {
            return left + right;
        });
        System.out.println(i);

    }

    public static int calculateNum(IntBinaryOperator operator) {
        int a = 10;
        int b = 20;
        return operator.applyAsInt(a, b);
    }*/
//=======================================================================


        //原来
        typeConver(new Function<String, Integer>() {
            @Override
            public Integer apply(String s) {
                return Integer.valueOf(s);
            }
        });

        //lambda
        Integer integer = typeConver((String s) -> {
            return Integer.valueOf(s);
        });

        System.out.println(integer);


    }
    public static <R> R typeConver(Function<String,R> function){

        String str = "12345";
        R apply = function.apply(str);
        return apply;
    }

}
