package com.wyk.pojo;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamDemo {

    public static void main(String[] args) {
        List<Author> authors = getAuthors();

        //单列集合
        //tes01(authors);
        //map集合
        //test02();
        //test03();
        //test05();
        //test06();
        //test07();
        //tes08();
        //tes09();
        //test10();
        //test11();
        //test12();
        //test13();
        //test14();
        //test15();
        //test16();
        //test17();
        //test18();
        //test19();
         // test20();
        //test21();
        //test22();
        //test23();
        test24();

        //集合创建stream流
        // Stream<Author> stream = authors.stream();

        /*//数组：`Arrays.stream(数组) `或者使用`Stream.of`来创建
        Integer[] arr = {1,2,3,4,5};
        Stream<Integer> stream = Arrays.stream(arr);
        Stream<Integer> stream1 = Stream.of(arr);*/


    }

    //### 并行流
    private static void test24() {
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        Integer sum = stream.parallel()
                .peek(num -> System.out.println(num+Thread.currentThread().getName()))
                .filter(num -> num > 5)
                .reduce(Integer::sum)
                .get();
        System.out.println(sum);
    }



    //基本数据类型优化
    private static void test23() {
        /*
        List<Author> authors = getAuthors();
        authors.stream()
                .map(Author::getAge)
                .map(age -> age + 10)
                .filter(age->age>18)
                .map(age->age+2)
                .forEach(System.out::println);
        */
        List<Author> authors = getAuthors();
        authors.stream()
                .mapToInt(Author::getAge)
                .map(age->age+20)
                .filter(age->age>18)
                .map(age->age+2)
                .forEach(System.out::println);

    }

    private static void test22() {
        //构造器引用
        List<Author> authors = getAuthors();
        authors.stream()
                .map(Author::getName)
                .map(StringBuilder::new)
                .map(sb -> sb.append("-三更").toString())
                .forEach(System.out::println);
    }

    private static void test21() {
    /*  如果我们在重写方法的时候，方法体中**只有一行代码**，
        并且这行代码是**调用了某个对象的成员方法**，并且我们把要重
    写的**抽象方法中所有的参数都按照顺序传入了这个成员方法中**，这个时候我们就可以引用对象的实例方法*/

        List<Author> authors = getAuthors();
        Stream<Author> authorStream = authors.stream();
        StringBuilder sb = new StringBuilder();
        authorStream.map(Author::getName)
                .forEach(sb::append);

    }

    private static void test20() {
        //方法引用
        //如下代码就可以用方法引用进行简化
        List<Author> authors = getAuthors();
        Stream<Author> authorStream = authors.stream();
        authorStream.map(author -> author.getAge())
                .map(String::valueOf);

    }

    private static void test19() {
    /*    - 不会影响原数据（我们在流中可以多数据做很多处理。
        但是正常情况下是不会影响原来集合中的元素的。这往往也是我们期望的）

        */


    }

    private static void test18() {
        List<Author> authors = getAuthors();

        Stream<Author> stream = authors.stream();
        stream .map(author -> author.getAge())
                .forEach(age-> System.out.println(age));

        // 流是一次性的（一旦一个流对象经过一个终结操作后。这个流就不能再被使用）

        /*stream().map(author -> author.getAge())
                .forEach(age-> System.out.println(age));*/
    }

    private static void test17() {
        //如果用一个参数的重载方法去求最小值代码如下：
        List<Author> authors = getAuthors();
        Optional<Integer> reduce = authors.stream()
                .map(author -> author.getAge())
                .reduce((result, element) -> result > element ? element : result);
        reduce.ifPresent(age-> System.out.println(age));

    }

    //两个参数
    private static void test16() {
        //使用reduce求所有作者年龄的和
        List<Author> authors = getAuthors();
   /*     Integer reduce = authors.stream()
                .distinct()
                .map(author -> author.getAge())
                .reduce(0, (result, element) -> result + element);
        System.out.println(reduce);*/

        //使用reduce求所有作者中年龄的最大值

       /* Integer reduce = authors.stream()
                .map(author -> author.getAge())
                .reduce(Integer.MIN_VALUE, (result, element) -> result < element ? element : result);

        System.out.println(reduce);*/

        //使用reduce求所有作者中年龄的最小值

        Integer reduce = authors.stream()
                .map(author -> author.getAge())
                .reduce(Integer.MAX_VALUE, (result, element) -> result > element ? element : result);
        System.out.println(reduce);


    }

    private static void test15() {

        List<Author> authors = getAuthors();
        //获取任意一个年龄大于18的作家，如果存在就输出他的名字
/*  Optional<Author> optional = authors.stream()
                .filter(author -> author.getAge() > 18)
                .findAny();

        System.out.println(optional);
        optional.ifPresent(author -> System.out.println(author.getName()));*/
//	获取一个年龄最小的作家，并输出他的姓名。
        Optional<Author> first = authors.stream()
                .sorted((o2, o1) -> o2.getAge() - o1.getAge())
                .findFirst();
        System.out.println(first);
        first.ifPresent(author -> System.out.println(author.getAge()));


    }

    private static void test14() {
        //判断是否有年龄在29以上的作家
        List<Author> authors = getAuthors();
        /*boolean b = authors.stream()
                .anyMatch(author -> author.getAge() > 29);
        System.out.println(b);*/

        // 判断是否所有的作家都是成年人
        /*
        boolean allMatch = authors.stream()
                .allMatch(author -> author.getAge() >= 18);
        System.out.println(allMatch);*/

        //判断作家是否都没有超过100岁的。

        boolean b = authors.stream()
                .noneMatch(author -> author.getAge() > 100);
        System.out.println(b);
    }

    private static void test13() {
        //	获取一个存放所有作者名字的List集合。
        List<Author> authors = getAuthors();
      /*  List<String> collect = authors.stream()
                .map(author -> author.getName())
                .collect(Collectors.toList());
        System.out.println(collect);
*/
//        //	获取一个所有书名的Set集合。
//        Set<String> collect = authors.stream()
//                .flatMap(author -> author.getBooks().stream())
//                .map(book -> book.getName())
//                .collect(Collectors.toSet());
//        System.out.println(collect);

        //获取一个Map集合，map的key为作者名，value为List<Book>
        Map<String, List<Book>> collect = authors.stream()
                .distinct()
                .collect(Collectors.toMap(author -> author.getName(),
                        author -> author.getBooks()));
        System.out.println(collect);

    }

    private static void test12() {
        //分别获取这些作家的所出书籍的最高分和最低分并打印。

        List<Author> authors = getAuthors();
        Optional<Integer> max = authors.stream()
                .flatMap(author -> author.getBooks().stream())
                .map(book -> book.getScore())
                .max((o1, o2) -> o1 - o2);


        Optional<Integer> min = authors.stream()
                .flatMap(author -> author.getBooks().stream())
                .map(book -> book.getScore())
                .min((o1, o2) -> o1 - o2);

        System.out.println(max.get());
        System.out.println(min.get());
    }

    private static void test11() {
        //打印这些作家的所出书籍的数目，注意删除重复元素。
        List<Author> authors = getAuthors();
        long count = authors.stream()
                .flatMap(author -> author.getBooks().stream())
                .distinct()
                .count();

        System.out.println(count);


    }

    private static void test10() {
        //	打印所有书籍的名字。要求对重复的元素进行去重。
        List<Author> authors = getAuthors();
      /*  authors.stream()
                .flatMap(author -> author.getBooks().stream())
                .distinct()
                .forEach(book -> System.out.println(book.getName()));*/
        authors.stream()
                .flatMap(author -> author.getBooks().stream())
                .distinct()
                .forEach(book -> System.out.println(book.getName()));
    }

    private static void tes09() {
//打印除了年龄最大的作家外的其他作家，要求不能有重复元素，并且按照年龄降序排序。
        List<Author> authors = getAuthors();
        authors.stream()
                .distinct()
                .sorted(((o1, o2) -> o2.getAge() - o1.getAge()))
                .skip(1)
                .forEach(author -> System.out.println(author.getAge()));
    }

    private static void tes08() {
//        对流中的元素按照年龄进行降序排序，并且要求不能
//    有重复的元素,然后打印其中年龄最大的两个作家的姓名。
        List<Author> authors = getAuthors();

        authors.stream()
                .distinct()
                .sorted(((o1, o2) -> o1.getAge() - o2.getAge()))
                .limit(2)
                .forEach(author -> System.out.println(author.getName()));
    }

    private static void test07() {
        // 对流中的元素按照年龄进行降序排序，并且要求不能有重复的元素。 空参
        List<Author> authors = getAuthors();
        /*authors.stream()
                .distinct()
                .sorted()
                .forEach(author -> System.out.println(author.getAge()));*/

        // 有参
        authors.stream()
                .distinct()
                .sorted(((o1, o2) -> o1.getAge() - o2.getAge()))
                .forEach(author -> System.out.println(author.getAge()));
    }

    private static void test06() {
        // 打印所有作家的姓名，并且要求其中不能有重复元素。
        List<Author> authors = getAuthors();
//        authors.stream()
//                .map(author -> author.getName())
//                .distinct()
//                .forEach(name -> System.out.println(name));
        authors.stream()
                .distinct()
                .forEach(author -> System.out.println(author.getName()));

    }

    private static void test05() {
        //打印作家的名字
        List<Author> authors = getAuthors();
//        authors.stream()
//                .map(author -> author.getName())
//                .forEach(s -> System.out.println(s));

     /*   authors.stream()
                        .forEach(author -> System.out.println(author.getName()));
        */
        //流中元素计算
       /*  authors.stream()
                 .map(author -> author.getAge())
                 .map(age-> age+10)
                 .forEach(age-> System.out.println(age));*/

        authors.stream()
                .map(author -> author.getAge())
                .map(age -> age + 10)
                .forEach(age -> System.out.println(age));


    }

    private static void test03() {
        //打印所有作家大于1的名字
        Stream<Author> stream = getAuthors().stream();
    /*  stream.filter(author -> author.getName().length()>1)
              .forEach(author -> System.out.println(author.getName()));*/

        stream.filter(author -> author.getName().length() > 1)
                .forEach(author -> System.out.println(author.getName()));

    }

    private static void test02() {
        //双列集合：转换成单列集合后再创建
        Map<String, Integer> map = new HashMap<>();
        map.put("蜡笔小新", 19);
        map.put("黑子", 17);
        map.put("日向翔阳", 16);
        Set<Map.Entry<String, Integer>> entrySet = map.entrySet();
        entrySet.stream()
                .filter(entry -> entry.getValue() > 16)
                .forEach(entry -> System.out.println(entry.getKey() + "==" + entry.getValue()));
    }

    private static void tes01(List<Author> authors) {
        authors.stream()
                .distinct()
                .filter(author -> author.getAge() < 18)
                .forEach(author -> System.out.println(author.getName()));
    }

    private static List<Author> getAuthors() {
        //数据初始化
        Author author = new Author(1L, "蒙多", 33, "一个从菜刀中明悟哲理的祖安人", null);
        Author author2 = new Author(2L, "亚拉索", 15, "狂风也追逐不上他的思考速度", null);
        Author author3 = new Author(3L, "易", 14, "是这个世界在限制他的思维", null);
        Author author4 = new Author(3L, "易", 14, "是这个世界在限制他的思维", null);

        //书籍列表
        List<Book> books1 = new ArrayList<>();
        List<Book> books2 = new ArrayList<>();
        List<Book> books3 = new ArrayList<>();

        books1.add(new Book(1L, "刀的两侧是光明与黑暗", "哲学,爱情", 88, "用一把刀划分了爱恨"));
        books1.add(new Book(2L, "一个人不能死在同一把刀下", "个人成长,爱情", 99, "讲述如何从失败中明悟真理"));

        books2.add(new Book(3L, "那风吹不到的地方", "哲学", 85, "带你用思维去领略世界的尽头"));
        books2.add(new Book(3L, "那风吹不到的地方", "哲学", 85, "带你用思维去领略世界的尽头"));
        books2.add(new Book(4L, "吹或不吹", "爱情,个人传记", 56, "一个哲学家的恋爱观注定很难把他所在的时代理解"));

        books3.add(new Book(5L, "你的剑就是我的剑", "爱情", 56, "无法想象一个武者能对他的伴侣这么的宽容"));
        books3.add(new Book(6L, "风与剑", "个人传记", 100, "两个哲学家灵魂和肉体的碰撞会激起怎么样的火花呢？"));
        books3.add(new Book(6L, "风与剑", "个人传记", 100, "两个哲学家灵魂和肉体的碰撞会激起怎么样的火花呢？"));

        author.setBooks(books1);
        author2.setBooks(books2);
        author3.setBooks(books3);
        author4.setBooks(books3);

        List<Author> authorList = new ArrayList<>(Arrays.asList(author, author2, author3, author4));
        return authorList;
    }

}
