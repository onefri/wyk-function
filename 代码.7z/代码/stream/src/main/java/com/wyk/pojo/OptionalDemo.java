package com.wyk.pojo;


import java.util.List;
import java.util.Optional;


public class OptionalDemo {

    public static void main(String[] args) {

      /*  Optional<Author> optional = getOptional();
        optional.ifPresent(author -> System.out.println(author.getName()));*/
        /*
//安全获取值orElseGet
        Optional<Author> optional = getOptional();
        //new Author()可以设置默认值
        Author author = optional.orElseGet(() -> new Author());
        System.out.println(author);*/
/*
        //orElseThrow抛出异常
        Optional<Author> optional = getOptional();
        Author author = optional.orElseThrow(() -> new RuntimeException("数据为null"));
        System.out.println(author);*/
/*
        //过滤
        Optional<Author> optional = getOptional();
        Optional<Author> author1 = optional.filter(author -> author.getAge() > 18);
        System.out.println(author1);
        */
/*
        //判断isPresent
        Optional<Author> optional = getOptional();
        if (optional.isPresent()){
            String name = optional.get().getName();
            Integer age = optional.get().getAge();
            System.out.println(name);
            System.out.println(age);
        }*/

//        Optional还提供了map可以让我们的对数据进行转换，
//        并且转换得到的数据也还是被Optional包装好的，保证了我们的使用安全。
        Optional<Author> authorOptional = getOptional();
        Optional<List<Book>> optionalBooks = authorOptional.map(author -> author.getBooks());
        optionalBooks.ifPresent(books -> System.out.println(books));

    }

    private static Optional<Author> getOptional() {
        //数据初始化
        Author author = new Author(1L, "蒙多", 33, "一个从菜刀中明悟哲理的祖安人", null);

        return Optional.ofNullable(author);
    }

    private static Author getAuthor() {
        //数据初始化
        Author author = new Author(1L, "蒙多", 33, "一个从菜刀中明悟哲理的祖安人", null);

        return null;
    }

}




